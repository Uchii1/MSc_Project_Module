# admin.py for quiz folder

# Models for quiz registered here
from django.contrib import admin


