import time
from django.shortcuts import render, redirect
from .logic import QUESTIONS, new_question, comment

MAX_ATTEMPTS = 3

def start(request):
    request.session["quiz"] = {
        "i": 0, "score": 0, "attempts": 0, "msg": "",
        "start": time.time(), "q": new_question(0),
    }
    return redirect("question")

def question(request):
    quiz = request.session.get("quiz")
    if not quiz:
        return render(request, "quiz/intro.html", {"total": len(QUESTIONS)})

    error =  " "
    if request.method == "POST":
        try:
            guess = int(request.POST["answer"])
        except (ValueError, KeyError):
            error = "Please enter a valid integer!"   # not counted as an attempt
        else:
            quiz["attempts"] += 1
            answer = quiz["q"]["answer"]
            advance = True
            if guess == answer:
                quiz["score"] += int(quiz["attempts"] == 1)  # mark only if first try
                quiz["msg"] = " "
            elif quiz["attempts"] >= MAX_ATTEMPTS:
                quiz["msg"] = f"The correct answer is {answer}. Moving on..."
            else:
                quiz["msg"] = "Try again please"
                advance = False

            if advance:
                quiz["i"] += 1
                quiz["attempts"] = 0
                if quiz["i"] >= len(QUESTIONS):
                    request.session.pop("quiz")
                    return render(request, "quiz/result.html", {
                        "score": quiz["score"], "total": len(QUESTIONS),
                        "time": round(time.time() - quiz["start"], 2),
                        "comment": comment(quiz["score"]), "msg": quiz["msg"],
                    })
                quiz["q"] = new_question(quiz["i"])
            request.session["quiz"] = quiz  # reassign so the session saves

    return render(request, "quiz/question.html", {
        "q": quiz["q"], "n": quiz["i"] + 1, "total": len(QUESTIONS),
        "msg": quiz["msg"], "error": error,
    })