# URL configuration for StudySoft
from django.urls import path
from . import views
from django.conf import settings
from django.conf.urls.static import static
from django.contrib import admin
from django.urls import path
from .views import PlaceholderView

# Designing login page
from django.urls import path, include

# Designing sign up page
from .views import SignUpView

# urls.py
from django.urls import path
from . import views


urlpatterns = [
    path("accounts/", include("django.contrib.auth.urls")),  # provides "login"
    path("signup/", SignUpView.as_view(), name="signup"),
    
    path('', views.home, name='home'),
    path('quiz/', views.quiz, name='quiz'),
    path('api/get-quiz/', views.get_quiz, name='get_quiz'),
    
    # Registering the view to save quiz results
    path('api/submit-quiz/', views.submit_quiz, name='submit_quiz'),

    path("geometric-formulae/", views.geometric_formulae, name="geometric_formulae"),
    path("pomodoro-timer/", views.pomodoro_timer, name="pomodoro_timer"),
    path("break-resources/", views.break_resources, name="break_resources"),
    path("about/", views.about, name="about"),

    path('progress/', views.progress, name='progress'),
    path('api/progress-data/', views.progress_data, name='progress-data'),
    path("guess-game/", views.guess_game_page, name="guess_game"),
    path("guess-game/guess/", views.guess_game_guess, name="guess_game_guess"),
    
    path("about/", views.about, name="about"),
    path("privacy/", views.privacy, name="privacy"),
    path("accessibility/", views.accessibility, name="accessibility"),

    path("syllabus/", views.syllabus, name="syllabus"),
    path("contact/", views.contact, name="contact"),
    path("font/", views.choose_font, name="choose_font"),
]


# Debugging text
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)



