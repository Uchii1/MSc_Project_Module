def font_choice(request):
    if request.user.is_authenticated:
        profile = getattr(request.user, "profile", None)
        return {"user_font": profile.font if profile else "system"}
    return {"user_font": "system"}